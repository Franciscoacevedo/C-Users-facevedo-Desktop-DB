# hello-pipelines
Simple set of .Net Core 3.0 projects used to try out Azure Pipelines concepts.

[![Build Status](https://dev.azure.com/julioc0382/hello-pipelines/_apis/build/status/julioct.hello-pipelines?branchName=master)](https://dev.azure.com/julioc0382/hello-pipelines/_build/latest?definitionId=1&branchName=master)